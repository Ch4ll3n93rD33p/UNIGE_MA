# Lea Heiniger
# 16.11.2023
# TALN - TP2

import string
import numpy as np
from gensim.models import Word2Vec, KeyedVectors
from sklearn.metrics.pairwise import cosine_similarity
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
import gensim.downloader as api

'''
This file is a library of functions used for the TP.
The main scripts can be found in the files "load_tp2.py" and "train_tp2.py".
'''

def sent_preprocessing(filename : str) -> tuple[list, list] :
    '''
    Function that preprocess the sentences from the test file.

    Parameters :
        filename -> the name of the raw text file
    
    Return :
        labels -> a list that contains the ID of each sentence
        sent -> a list that contains the preprocessed sentences
    '''
    with open(filename, 'r') as f :

        lines = []
        for line in f :
            lines.append(line) 
    
    labels = []
    sent = []
    
    for l in lines :
        l = l.lower() 
        no_punct = str.maketrans('', '', string.punctuation)
        l = l.translate(no_punct)
        s = l.split()
        labels.append(s[0])
        sent.append(s[1:])
        
    return labels, sent

def get_sent_vectors(sent : list, word_vectors, load_script = True) -> np.ndarray :
    '''
    Function that computes the sentences vectors from the words vectors

    Parameters :
        sent -> a list that contains the preprocessed sentences
        word_vectors -> the model's keyed vectors for each word
        load_script -> a parameter to adapt the function between load and train scripts
    
    Return :
        sent_vectors -> the array that contains the vector of each sentence        
    '''
    sent_vectors = []

    for s in sent :
        if load_script :
            vectors = [word_vectors[w] for w in s if w in word_vectors.key_to_index]
        else :
            vectors = [word_vectors.wv[w] for w in s if w in word_vectors.wv]

        if vectors == [] :
            sent_vectors.append(np.zeros(word_vectors.vector_size))
        else :
            sent_vectors.append(np.mean(vectors, axis = 0))

    return np.array(sent_vectors)

def most_sim_sent(sent_vectors : np.ndarray) -> list[int] :
    '''
    Function that finds the most similar sentence for each target sentence.

    Parameters :
        sent_vectors -> the array that contains the vector of each sentence
    
    Return :
        most_sim_index -> a list that contains the most similar sentence index for each sentence
    '''
    most_sim_index = []
    sim_matrix = cosine_similarity(sent_vectors)
    np.fill_diagonal(sim_matrix, -1)

    for i in range(len(sent_vectors)) :
        most_sim_index.append(np.argmax(sim_matrix[i]))
        
    return most_sim_index

def plot_sent_embedding(sent_vectors : np.ndarray, labels : list, filename : str) -> None :
    '''
    Function that saves the plot of the sentence embedding using TSNE.

    Parameters :
        sent_vectors -> the array that contains the vector of each sentence
        labels -> a list that contains the ID of each sentence
        filename -> the name of the saved plot
    '''
    tsne = TSNE(n_components=2, random_state=0, perplexity=30, learning_rate=200)
    vectors = tsne.fit_transform(sent_vectors)

    fig = plt.figure(figsize = [10, 10])
    for i in range(len(vectors)):
        plt.scatter(vectors[i][0], vectors[i][1])
        plt.text(vectors[i][0], vectors[i][1], labels[i])

    plt.title('sentence embedding with labels from the test file')
    plt.savefig(filename)

def write_output(filename : str, most_sim_index : list[int], labels : list) -> None :
    '''
    Function that writes the input sentence ID and the ID of the most similar sentence in a file.

    WARNING: if a file called raw_text.txt already exists
    it will be overwritten !

    Parameters :
        filename -> the name of the output file
        most_sim_index -> a list that contains the most similar sentence index for each sentence
        labels -> a list that contains the ID of each sentence
    '''
    with open(filename, 'w') as f :
        for i in range(len(most_sim_index)) :
            f.write(str(labels[i])+'\t'+str(labels[most_sim_index[i]])+'\n')