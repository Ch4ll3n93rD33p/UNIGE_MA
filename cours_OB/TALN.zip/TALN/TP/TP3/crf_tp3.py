# Lea Heiniger
# 14.12.2023
# TALN - TP3

import sklearn_crfsuite
import functions as func
import time

start = time.time()

languages = ['Chinese', 'Croatian', 'Danish', 'English', 'Portugese', 'Serbian', 'Slovak', 'Swedish']
train_filenames = ['UNER_Chinese-GSDSIMP/zh_gsdsimp-ud-train.iob2', 'UNER_Croatian-SET/hr_set-ud-train.iob2', 'UNER_Danish-DDT/da_ddt-ud-train.iob2', 'UNER_English-EWT/en_ewt-ud-train.iob2', 'UNER_Portuguese-Bosque/pt_bosque-ud-train.iob2', 'UNER_Serbian-SET/sr_set-ud-train.iob2', 'UNER_Slovak-SNK/sk_snk-ud-train.iob2', 'UNER_Swedish-Talbanken/sv_talbanken-ud-train.iob2']
test_filenames = ['UNER_Chinese-GSDSIMP/zh_gsdsimp-ud-test.iob2', 'UNER_Croatian-SET/hr_set-ud-test.iob2', 'UNER_Danish-DDT/da_ddt-ud-test.iob2', 'UNER_English-EWT/en_ewt-ud-test.iob2', 'UNER_Portuguese-Bosque/pt_bosque-ud-test.iob2', 'UNER_Serbian-SET/sr_set-ud-test.iob2', 'UNER_Slovak-SNK/sk_snk-ud-test.iob2', 'UNER_Swedish-Talbanken/sv_talbanken-ud-test.iob2']

for i in range(8) :
    X_train, Y_train = func.load_data(train_filenames[i])
    X_test, Y_test = func.load_data(test_filenames[i])

    crf = sklearn_crfsuite.CRF( #TODO watch parameters
    algorithm='lbfgs',
    c1=0.1,
    c2=0.1,
    max_iterations=100,
    all_possible_transitions=True)

    crf.fit(X_train, Y_train)

    Y_pred = crf.predict(X_test)
    report = func.make_report(Y_test, Y_pred)
    func.write_report('crf_reports.txt', languages[i], report)

end = time.time()
print('running time : '+str(end-start)+' s')

