# Lea Heiniger
# 26.10.2023
# TALN - TP1

import functions as func
import sys

'''
This file is the main script and uses functions implemented in the file "functions.py".
More information on my TP and the instructions on how to run the script can be 
found in the file "README.md".
'''

# default values

window_size = 5
nB = 200
nT = 100


# user entry handing

arguments = sys.argv[1:]

if arguments[0] == '-p' : # raw test preprocessing
    
    func.text_preprocessing(arguments[1])
    filename = 'raw_text.txt'

    # window size option
    if '-ws' in arguments :
        i = arguments.index('-ws')
        window_size = int(arguments[i+1])
        arguments.pop(i+1)
        arguments.pop(i)
    
    if len(arguments)>2 : # sizes of B and T
        nB = int(arguments[2])
        nT = int(arguments[3])

    func.create_BandT(filename, nB, nT)
    fileB = 'B.txt'
    fileT = 'T.txt'

else :
    filename = arguments[0]
    fileB = arguments[1]
    fileT = arguments[2]

    # window size option
    if '-ws' in arguments :
            i = arguments.index('-ws')
            window_size = int(arguments[i+1])


# data loading from files

with open(filename, 'r') as f : # raw text
    rawtxt = ''
    for line in f :
        rawtxt += line

with open(fileB) as b: # B
    B = []
    for line in b :
        B.append(line[:-1])

with open(fileT) as t: # T
    T = []
    for line in t :
        T.append(line[:-1])


# 2D embeddings

coM = func.co_occ_matrix(rawtxt, B, T, window_size)
ppmiM = func.ppmi(coM)
pca_data = func.pca(ppmiM)
func.plot_words(pca_data[:, 0], pca_data[:, 1], T)


# Most similar words

most_sim = func.most_sim_words(ppmiM, T)
print(most_sim)
