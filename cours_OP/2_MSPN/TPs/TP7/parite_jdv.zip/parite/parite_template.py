import sys
import numpy as np
from matplotlib import pyplot as plt
from matplotlib import animation

# To run the code : python filename.py dataFileName.data numIter

# We import the data from the given file
init_lattice_list = []
with open("exemples/" + sys.argv[1], "r") as fd:
    for line in fd:
        new_row = line.split()
        init_lattice_list.append(new_row)
init_lattice = np.array(init_lattice_list, dtype=int)

lattice = init_lattice.copy()
# TODO define the lookup table
lut = 

fig = plt.figure()
im = plt.imshow(init_lattice, animated=True, interpolation="none")

def init():
    im.set_array(lattice)
    return im,

def animate(i):
    # We compute the lattice for the next time step
    global lattice
    
    # TODO compute the new state based on neighbours
    parity = 
    lattice = lut[parity]
    im.set_array(lattice)
    return im,
    
anim = animation.FuncAnimation(fig, animate, init_func=init, frames=int(sys.argv[2]), interval=100, blit=True, repeat=False)

plt.show()

# We write the final lattice in a file
with open("exemples/final/final_" + sys.argv[1], "w") as fd:
    nrow, _ = np.shape(lattice)
    for i in range(nrow):
        row = lattice[i,:]
        line = " ".join(list(row.astype(str)))
        fd.write(line + "\n")
