from pyswip import Prolog
prolog = Prolog()
prolog.consult("simple.pl")
c = list(prolog.query("person(X)"))
print(c)
