# Lea Heiniger
# 11.01.2024
# TALN - TP4

import numpy as np
from sklearn.metrics import classification_report
from transformers import BertTokenizerFast, BertForTokenClassification #, AdamW
import torch
from torch.utils.data import Dataset, DataLoader
from torch.optim import AdamW

'''
This file is a library of functions used for the TP.
The main scripts can be found in the file "finetune_tp4.py".
'''

def load_data(filename : str) -> tuple[list, list] :
    '''
    Loads the data from an IOB file
    '''

    with open(filename, 'r') as f :

        lines = []
        for line in f :
            lines.append(line) 
    
    X = []
    Y = []
    sentenceX = []
    sentenceY = []
    for line in lines :
        l = line.strip('\n')
        l = l.split('\t')
        if l[0].startswith('#') :
            pass
        elif l[0] == '' :
            X.append(sentenceX)
            Y.append(sentenceY)
            sentenceX = []
            sentenceY = []
        else :
            sentenceX.append(l[1])
            sentenceY.append(l[2])
        
    return X, Y

def convert_label(language : str, word_id : int, label, conv : str) -> int :
    '''
    Converts labels from IOB to Bert and from Bert to IOB
    '''

    if word_id == None and conv == 'to_Bert' :
        return -1
    
    elif language == 'Chinese' :
        lab = ['B-LOC', 'I-LOC', 'I-ORG', 'B-ORG', 'O', 'I-PER', 'B-PER']

    elif language == 'Croatian' :
        lab = ['B-LOC', 'I-OTH', 'I-LOC', 'I-ORG', 'B-ORG', 'I-PER', 'O', 'B-OTH', 'B-PER']
    
    elif language == 'Danish' :
        lab = ['B-LOC', 'I-LOC', 'I-ORG', 'B-ORG', 'I-PER', 'O', 'B-PER']
    
    elif language == 'English' :
        lab = ['B-LOC', 'I-LOC', 'I-ORG', 'B-ORG', 'O', 'I-PER', 'B-PER']

    elif language == 'Portuguese' :
        lab = ['B-LOC', 'I-LOC', 'I-ORG', 'B-ORG', 'I-PER', 'O', 'B-PER']

    elif language == 'Serbian' :
        lab = ['B-LOC', 'I-OTH', 'I-LOC', 'I-ORG', 'B-ORG', 'I-PER', 'O', 'B-OTH', 'B-PER']

    elif language == 'Slovak' :
        lab = ['B-LOC', 'I-LOC', 'I-ORG', 'B-ORG', 'I-PER', 'O', 'B-PER']

    elif language == 'Swedish' :
        lab = ['B-LOC', 'I-LOC', 'I-ORG', 'B-ORG', 'O', 'I-PER', 'B-PER']

    if conv == 'to_Bert' :
        return lab.index(label[word_id])
    elif conv == 'to_IOB' :
        return lab[label]

def tokenize(language : str, X : list, max_len : int, Y : list, tokenizer) -> dict :
    '''
    Tokenize the sentences from X using a Bert tokenizer
    '''

    token_dict = {'input_ids': [], 'token_type_ids': [], 'attention_mask': [], 'label' : []}
    l_tok = []
    for s, l in zip(X,Y) :
       s_tok = tokenizer(s, is_split_into_words=True, padding="max_length", max_length=max_len, truncation=True, return_tensors='pt')

       w_ids = s_tok.word_ids()

       l_ = [convert_label(language, w_i, l, 'to_Bert') for w_i in w_ids]
       l_ = l_+([-1]*(max_len-len(l_)))
       l_tok.append(l_)

       token_dict['input_ids'].append(s_tok['input_ids'][0])
       token_dict['token_type_ids'].append(s_tok['token_type_ids'][0])
       token_dict['attention_mask'].append(s_tok['attention_mask'][0])
    token_dict['label'] = torch.tensor(l_tok, dtype=torch.long)
    
    return token_dict

def train_(model, dataset_, device, optimizer, num_epochs : int = 5, accumulation_steps : int = 10) -> None :
    '''
    Train the model on a given train set (dataset_)
    '''

    for i in range(num_epochs) :
        optimizer.zero_grad()
        loss_ = 0

        for id, data in enumerate(dataset_) :
            input_ids = data['input_ids'].to(device)
            att_mask = data['attention_mask'].to(device)
            label = data['label'].to(device)
            res = model(input_ids, attention_mask=att_mask, labels=label)
            
            loss = res.loss/accumulation_steps
            loss.backward()

            loss_ += loss.item()*accumulation_steps

            if id == len(dataset_)-1 or (id+1)%accumulation_steps == 0 :
                optimizer.step() 
                optimizer.zero_grad()

def evaluate(language : str, model, dataset_, device) :
    '''
    Evaluates the model by trying to predict the labels of the given test set (dataset_)
    '''

    Y_test, Y_pred = [], []
    
    for data in dataset_ :
        input_ids = data['input_ids'].to(device)
        att_mask = data['attention_mask'].to(device)
        label = data['label'].to(device)
        res = model(input_ids, attention_mask=att_mask)
        
        pred = torch.argmax(res.logits, dim = 2)

        for j in range(pred.shape[0]):
            lab = label[j].tolist()
            lab_pred = pred[j].squeeze().tolist()
           
            for l, p in zip(lab, lab_pred):
                if l == -1 :
                    pass
                else : 
                    y = convert_label(language, None, l, conv = 'to_IOB')
                    Y_test.append(y)
                    y_p = y = convert_label(language, None, p, conv = 'to_IOB')
                    Y_pred.append(y_p)
                    
    return Y_test, Y_pred

def unify_lists(lst : list) -> list :
    '''
    Concatenate all teh sub lists from lst
    '''
    
    u = []
    for l in lst :
        u += l
    return u

def make_report(Y_test : list, Y_pred : list) :
    '''
    Creates a classification report using the sklearn function 
    '''

    Y_test = unify_lists(Y_test)
    Y_pred = unify_lists(Y_pred)
    return classification_report(Y_test, Y_pred, zero_division = 0.0)

def write_report(filename : str, language : str, report : str) :
    '''
    Writes a report at the end of a given file
    '''

    with open(filename, 'a') as f:
        f.write('\n\n'+language+'\n')
        f.write(report)
    
class CustomDataset(Dataset) :
    '''
    A customized class for data set
    '''

    def __init__(self, tokenized_sent : dict) -> None :
        self.tokenized_sent = tokenized_sent

    def __len__(self) -> int :
        return len(self.tokenized_sent['input_ids'])
    
    def __getitem__(self, id : str) -> dict :
        item = {}
        for k, v in self.tokenized_sent.items() :
            item[k] = v[id]
        return item
