
# a**n mod m recursive version : fails for large integers
def expmod(a,n,m):
    if n==0: return 1
    if n%2==0: return (expmod(a, n/2, m)**2) % m
    return (a*expmod(a,n-1,m)) % m

# computes a list "factor"  of the exponent i of the terms  2^i
# present in the decomposition of n in sum of power of 2
# If n=2^0 + 2^4 + 2^5, factor will be [0,4,5]
def power_2(n):
    m=n
    q=m
    exposant=[]
    while q>0:
        q=m//2
        r=m-2*q
        exposant.append(r)
        m=q
#    print(exposant)
    factors=[]
    for i in range(len(exposant)):
        if exposant[i]==1: factors.append(i)
#    print(factors)
    return factors


# a**n mod m, iterative version
def ExpMod(a,n,m):
    c=1
    factors=power_2(n)
    for i in range(len(factors)):
        b=a
        for i in range(factors[i]):
            b=(b*b)%m
#        print(b)
        c=(c*b)%m
    return c
    
# Note that the python function pow(a,n,m) works efficiently
# for large integers


a=7
n=561

print("a =",a, "n =",n-1, "m =",n)
print("expmod =", expmod(a,n-1,n))
print("ExpMod =", ExpMod(a,n-1,n))

a=21
print("a =",a, "n =",n-1, "m =",n)
print("expmod =", expmod(a,n-1,n))
print("ExpMod =", ExpMod(a,n-1,n))



#https://t5k.org/curios/index.php?start=20&stop=24

p1=31
p2=999331
p3=39916801
p4=479001599
p5= 87178291199
p6=67280421310721
p7=999779999159200499899

M_127=170141183460469231731687303715884105727  # 2**127 - 1
p8=20988936657440586486151264256610222593863921

q_false=651693055693681


a=21
n=p8  # too big for the recursive approach

print("a =",a, "n =",n-1, "m =",n)
print("expmod =", expmod(a,n-1,n))
print("ExpMod =", ExpMod(a,n-1,n))


