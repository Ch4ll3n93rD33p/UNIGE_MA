# Lea Heiniger
# 14.12.2023
# TALN - TP3

import string
import numpy as np
from sklearn.metrics import classification_report

'''
This file is a library of functions used for the TP.
The main scripts can be found in the files "load_tp2.py" and "train_tp2.py".
'''

def load_data(filename : str) -> tuple[list, list] :

    with open(filename, 'r') as f :

        lines = []
        for line in f :
            lines.append(line) 
    
    X = []
    Y = []
    sentenceX = []
    sentenceY = []
    for line in lines :
        l = line.strip('\n')
        l = l.split('\t')
        if l[0].startswith('#') :
            pass
        elif l[0] == '' :
            X.append(sentenceX)
            Y.append(sentenceY)
            sentenceX = []
            sentenceY = []
        else :
            sentenceX.append(l[1])
            sentenceY.append(l[2])
        
    return X, Y

def concatenate_tokens(split_X : list[list]) -> list :
    X = []
    for sentence in split_X :
        s = ' '.join(sentence)
        X.append(s)
    return X

def format(doc) :
    tags = []
    for i in range(len(doc)):
        t = doc[i]
        token =t.ent_iob_
        if token == 'O' :
            tags.append('O')
        elif token == 'B' :
            tags.append(f'B-{t.ent_type_}')
        elif token == 'I' :
            tags.append(f'I-{t.ent_type_}')
            '''else:
                raise ValueError(f'Invalid IOB tag: {token.ent_iob_}')'''

    return tags

def unify_lists(lst : list) -> list :
    u = []
    for l in lst :
        u += l
    return u

def make_report(Y_test : list, Y_pred : list) :
    Y_test = unify_lists(Y_test)
    Y_pred = unify_lists(Y_pred)
    return classification_report(Y_test, Y_pred, zero_division = 0.0)
    
def write_report(filename : str, language : str, report : str) :
    with open(filename, 'a') as f:
        f.write('\n\n'+language+'\n')
        f.write(report)
