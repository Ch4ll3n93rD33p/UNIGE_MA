n=2537

print("n =",n)

# sq[i] will contains all the sqrt(i) mod n found by exhausive search
sq=[[] for i in range(n) ]

for i in range(n):
    j=(i*i)%n
    sq[j].append(i)

for i in range(n):
    if sq[i]: print(i, sq[i])

