# Lea Heiniger
# 16.11.2023
# TALN - TP2

import functions as func
import sys
import time

'''
This file is the script that creates a sentence embedding by training a model from a corpus. 
It uses functions implemented in the file "functions.py".
More information on my TP and the instructions on how to run the script can be 
found in the file "README.md".
'''

start = time.time()

arguments = sys.argv[1:]
filename = arguments[0]

labels, sent = func.sent_preprocessing(filename)

# We train a model on the corpus  text8
corpus = func.api.load("text8")
model = func.Word2Vec(sentences = corpus)
model.save('word2vec.model')


# We compute the sentence embedding
sent_vectors = func.get_sent_vectors(sent, model, load_script = False)
func.plot_sent_embedding(sent_vectors, labels, 'out2.1.png')

# We find the most similar sentence for each sentence (exept self)
most_sim_index = func.most_sim_sent(sent_vectors)
func.write_output('out2.2.txt', most_sim_index, labels)


end = time.time()
print('running time : '+str(end-start)+' s')