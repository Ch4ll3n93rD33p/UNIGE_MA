def average_std(x, prob_dist_x):
    n=len(x)
    a=0
    v=0
    for i in range(n):
        a += x[i]*prob_dist_x[i]
        v += x[i]*x[i]*prob_dist_x[i]
    return (a, (v-a**2)**0.5)

def combineLV(prob_dist_1, prob_dist_2):
    n=len(prob_dist_1) # should be the same as prob_dist_2
    prob_dist_12=[0 for i in range(n)]
    for i in range(n):
        s1=0
        s2=0
        for j in range(i+1,n):
            s1 += prob_dist_1[j]
            s2 += prob_dist_2[j]
        prob_dist_12[i]=(prob_dist_1[i] + s1)*(prob_dist_2[i] + s2) - s1*s2
    return prob_dist_12


# read the probability distribution computed in TP3 for the random quickSort
        
f=open('quick-sort-time-dist-128.dat', 'r')

t=[] # possible times
p=[] # number of observations at this time

for line in f:
    data=line.split('  ')
    t.append(int(data[0]))
    p.append(int(data[1]))
f.close()

n=len(t) # or len(p)
nObservation=sum(p)  # because p[i] is not normalized in the file
for i in range(n): p[i] = p[i]/nObservation

a,s=average_std(t,p)
print("p: average =",a,"std =",s)

# compute the distribution of time for the algo in parallel
P=[0 for i in range(n)]

P=combineLV(p,p)
(a,s)=average_std(t,P)
print("p+p: average =",a,"std =",s)

Q=combineLV(P,p)
(a,s)=average_std(t,Q)
print("p+p+p: average =",a,"std =",s)

