# Lea Heiniger
# Information Systems Security
# TP 2

import Correc_TP1_AES_modif as aes
from operator import xor

def charToByte(msg) :
    '''
    Function that convert a string of characters to the ascii string corresponding

    Parameters :
     msg -> a string

    Returning :
     binMsg -> the string converted in ascii
    '''
    binMsg = ""

    for char in msg :
        binMsg = binMsg+paddingSeq(bin(ord(char))[2:])

    return(binMsg)

def byteToChar(binMsg) :
    '''
    Function that convert a string in ascii to the corresponding string of characters

    Parameters :
     msg -> an ascii string

    Returning :
     binMsg -> the string converted in characters
    '''
    msg = ""
    binChars = slicing(binMsg, 8)

    for char in binChars :
        msg = msg + chr(int("0b"+char, 2))

    return msg

def paddingSeq(bin, size=8) :
    '''
    Function that adds zeros in front of a string in order to have a string of length "size"

    Parameters :
     bin -> a binary string
     size -> leght that we want (default 8)

    Returning :
     bin -> the string padded
    '''
    while len(bin)<size :
        bin = "0"+bin
    return bin

def XOR(seq1, seq2) :
    '''
    Function that compute xor between two binary string

    Parameters :
     seq1 -> a binary string
     seq2 -> a binary string of same size as seq1

    Returning :
     res -> result of the xor opperation
    '''
    L = len(seq1)
    a = int("0b"+seq1,2)
    b = int("0b"+seq2,2)
    res = bin(xor(a,b))[2:]
    res = paddingSeq(res,L)
    return res

def multGF128(p1, p2, r = [7,2,1,0]) :
    '''
    Function that compute xor between two binary string

    Parameters :
     p1 -> a binary string
     p2 -> a binary string of same size as seq1
     r -> list of the power for the polynom (default [7,2,1,0])

    Returning :
     res -> result of the multiplication of p1 and p2 in GF128
    '''
    listP1 = list(p1)
    listP2 = list(p2)
    degP1 = len(p1)-1
    degP2 = len(p2)-1
    listRes = ["0" for _ in range(degP1+degP2+1)]

    degRes = degP1+degP2

    # multiplication
    for i in range(len(p1)) :

        if listP1[i] == '1' :

            for j in range(len(listP2)) :

                if listP2[j] == '1' :
                    d1 = degP1-i
                    d2 = degP2-j
                    dr = d1+d2
                    index = degRes-dr

                    if listRes[index] == '0' :
                        listRes[index] = '1'

                    else :
                        listRes[index] = '0'

    degMod = max(r)
    l = degMod+1
    resMod = []

    # modulo
    for i in range(l) :
        resMod.append('0')

    for d in r :
        resMod[degMod-d] = '1'

    while len(listRes) > len(p1) :

        if listRes[0] == '0':
            listRes.pop(0)

        else :
            for j in range(len(resMod)) :

                if listRes[j] == resMod[j] :
                    listRes[j] = '0'

                else :
                    listRes[j] = '1'

    res = ''.join(listRes)

    return res

def hashSubkey(K) :
    '''
    Function that compute H

    Parameters :
     K -> a 128, 192 or 256 bits key

    Returning :
     H -> result of the AES box encryption on 128-bits full zero message
    '''
    seq = paddingSeq("", 128)
    H = charToByte(aes.AES_Box(None, K, zero = True))
    return H

def pad(A, C) :
    '''
    Function that pads the Additional Authenticated Data
    and the plaintext

    Parameters :
     A -> a binary string
     C -> the ciphertext (as a binary string)

    Returning :
     A -> the string padded
     C -> the ciphertext padded
     L -> a binary string of the unpadded sizes of A and C (64bits each)
    '''

    LA = bin(len(A))[2:]
    LC = bin(len(C))[2:]
    L = paddingSeq(LA, size=64)+paddingSeq(LC, size=64)

    v = len(A)%128
    u = len(C)%128
    A = A+(128-v)*"0"
    C = C+(128-u)*"0"

    return A, C, L

def slicing(msg, size=128) :
    '''
    Function that slice a string into blocks of size "size"

    Parameters :
     msg -> a string
     size -> leght of the blocks (default 128)

     Returning :
      slicedMsg -> a list of the blocks
     '''
    slicedMsg = []

    for i in range(len(msg)//size) :
        slicedMsg.append(msg[i*size:(i+1)*size])

    if len(msg)%size!=0 :
        slicedMsg.append(msg[(len(msg)//size)*size:])

    return slicedMsg

def authentication(slicedA, slicedC, L, H) :
    '''
    Function that computes the authentication tag (except the last xor with Cstart)

    Parameters :
     slicedA -> a list of binary strings (sub blocks of A)
     slicedC -> a list of binary strings (sub blocks of C)
     L -> a binary string of the unpadded sizes of A and C (64bits each)
     H -> hash subkey

     Returning :
      T -> the authentication tag (as a binary string)
     '''
    T = multGF128(slicedA[0], H)

    for i in range(1, len(slicedA)) :
        T = XOR(T, slicedA[i])
        T = multGF128(T, H)

    for j in range(len(slicedC)) :
        T = XOR(T, slicedC[j])
        T = multGF128(T, H)

    T = XOR(T, L)
    T = multGF128(T, H)

    return T

def initCounterVal(IV, H) :
    ''''
    Function that compute the initial counter value

    Parameters :
     IV -> a binary string
     H -> hash subkey

     Returning :
      count0 -> a binary string
     '''
    if len(IV)==96 :
        cont0 = IV+31*"0"+"1"

    else :
        A = ""
        C = IV
        A, C, L = pad(A, C)
        slicedA = slicing(A)
        slicedC = slicing(C)
        count0 = authentication(slicedA, slicedC, L, H)

    return count0

def incrementCount(count) :
    ''''
    Function that increments the counter of 1

    Parameters :
     count -> a binary string

     Returning :
      the counter incremented
     '''
    l = len(count)
    add1 = str(bin(int("0b"+count,2)+0b1))[2:]
    count = paddingSeq(add1, l)
    return count

def encryptionGaloisCounterMode(P, IV, K, A) :
    ''''
    Function that performs the Galois Counter Mode encryption

    Parameters :
     P -> the plaintext (a string)
     IV -> the initialisation value (a string)
     K -> the key (a string of size 128, 192 or 256)
     A -> the additional authenticated data (a string)

     Returning :
      C -> the ciphertext (a string)
      T -> the authentication tag (a string)
     '''
    H = hashSubkey(K)
    binIV = charToByte(IV)
    binCount0 = initCounterVal(binIV, H)
    count0 = byteToChar(binCount0)

    Cstart = charToByte(aes.AES_Box(count0, K))

    # encryption of the plaintext
    binP = charToByte(P)
    slicedP = slicing(binP)
    count = incrementCount(Cstart)

    C = ""
    for i in range(len(slicedP)-1) :

        encryCount = charToByte(aes.AES_Box(byteToChar(count), K))
        C = C+XOR(encryCount, slicedP[i])
        count = incrementCount(count)

    # last one may not be 128-bits long
    encryCount = charToByte(aes.AES_Box(byteToChar(count), K))
    l = len(slicedP[-1])
    C = C+XOR(encryCount[:l], slicedP[-1])

    # computation of T
    paddedA, paddedC, L =pad(A, C)
    slicedA = slicing(paddedA)
    slicedC = slicing(paddedC)
    T = authentication(slicedA, slicedC, L, H)
    T = XOR(T, Cstart)

    C = byteToChar(C)
    T = byteToChar(T)

    return C, T

def decryptionGaloisCounterMode(C, T, IV, K, A) :
    ''''
    Function that performs the Galois Counter Mode decryption

    Parameters :
     C -> the ciphertext (a string)
     T -> the authentication tag (a string)
     IV -> the initialisation value (a string)
     K -> the key (a string of size 128, 192 or 256)
     A -> the additional authenticated data (a string)

     Returning :
      P -> the plaintext (a string)
     '''
    H = hashSubkey(K)
    binIV = charToByte(IV)
    binCount0 = initCounterVal(binIV, H)
    count0 = byteToChar(binCount0)

    Cstart = charToByte(aes.AES_Box(count0, K))

    # computation of T
    C = charToByte(C)
    paddedA, paddedC, L =pad(A, C)
    slicedA = slicing(paddedA)
    slicedC1 = slicing(paddedC)
    T2 = authentication(slicedA, slicedC1, L, H)
    T2 = XOR(T2, Cstart)

    T = charToByte(T)

    # we check the authentication tag
    if T!=T2 :
        return 'FAIL'

    else :

        # if the tag is ok we decrypt the plaintext
        binC = charToByte(C)
        count = incrementCount(Cstart)

        P = ""
        slicedC = slicing(C)

        for i in range(len(slicedC)-1) :
            encryCount = charToByte(aes.AES_Box(byteToChar(count), K))
            P = P+XOR(encryCount, slicedC[i])
            count = incrementCount(count)

        # last one may not be 128-bits long
        encryCount = charToByte(aes.AES_Box(byteToChar(count), K))
        l = len(slicedC[-1])
        P = P+XOR(encryCount[:l], slicedC[-1])

        P = byteToChar(P)

        return P
