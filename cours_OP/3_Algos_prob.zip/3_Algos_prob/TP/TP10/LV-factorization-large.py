import random

def gcd(a,b):
    r0=a
    r1=b
    r2=r0%r1
    q=r0//r1
    while r2 !=0 :
        r0=r1
        r1=r2
        r2=r0%r1
        q=r0//r1
    return r1


# build a list "prime[i]" with the first nPrime prime numbers

def build_prime(nPrime):
    prime=[2]  # initialization with the first prime number
    i=prime[-1]
    while len(prime)<nPrime:
        i +=1
        for p in prime:
            if i%p == 0: break
        else:
            prime.append(i)
    return prime


# determines if y is k-smooth, that is y can be decomposed on the
# first nPrime prime numbers
def k_smooth(y,prime):
    factors=[]
    for p in prime:
        i=0
        while y%p == 0:
            i+=1
            y=y//p
        factors.append(i)
    return (y==1, factors) #  factors[i] contains the power of prime[i]
                           #  needed to represent y;
                           #  if y==1, it means success: all factors are
                           # sufficiaent


# Find randomly x in {1,n-1} and y=x^2 mod n, with y k-smooth;
# Add the decomèosition of y as a new row to matrix Y;
# Add x and y to matrix XY
def find_x_y(n,prime, XY, Y):
    s=False
    while not s:
        x=random.randint(1,n-1)
        y=pow(x,2,n)
        (s,factor)=k_smooth(y,prime)
        if s==True:
            print("x =",x,"y =",y)
            XY.append((x,y))
            Y.append(factor)

# finds nRepeat couple x y and y decomposition 
def repeatFind_x_y(n,prime, XY, Y,nRepeat):
    nCount=0
    while nCount<nRepeat:
        find_x_y(n,prime, XY, Y)
        nCount+=1

# M will extend the matrix Y with the concatenation of the Identiy matirx
# for each variable y_i corresponding to a row of Y
def build_M(Y):
    nRow=len(Y)  # number of y's
    nCol=len(Y[0]) # number of primes (nPrime)
    M=[]
    for i in range(nRow):
        row=[]
        for j in range(nCol):
            row.append(Y[i][j]%2)  # we take only the parity
        for j in range(nRow):
            if j==i: row.append(1)
            else: row.append(0)
        M.append(row)
    return M


# add row i to row k of matrix M
# for indices 0 t0 nPrime-1, use mod 2 aarithmetics
# for indices nPrime to len(M)+nPrime-1, use normal arithetics
def addRows(M,nPrime,i,k):
    nRow=len(M)
    for j in range(nPrime):
        M[k][j]=(M[k][j] + M[i][j])%2
    for j in range(nPrime, nPrime + nRow):
        M[k][j]=(M[k][j] + M[i][j])

def GaussianElimnation(M,nPrime):
    sol=[] # this will contains all the row indices of rows with zeros
    nRow=len(M)
    cCol=nRow + nPrime
    for i in range(nRow):
        for j in range(nPrime):
            if M[i][j]== 0: continue
            for k in range(nRow):
                if k==i: continue
                if M[k][j]==1:
                    addRows(M,nPrime,i,k)
            break # end of j loop, go to next i
        else:
            # print("Found row",i, "with all zeros")
            # print(M[i],"\n")
            sol.append(i)
    return sol

def find_perfect_square_root(M, prime, XY, Y, Sol,solIndex,n):
    nRow=len(M) # number of y_i
    nPrime=len(prime)
    nCol=nRow + nPrime

    row=Sol[solIndex] # a possibility to build a perfect square
    perfect_square=[0 for j in range(nPrime)]
    sqrt_x=1 #
    sqrt_y=1 #
    for i in range(nPrime,nCol):
        sqrt_x = (sqrt_x * pow(XY[i-nPrime][0],M[row][i],n)) % n
        for j in range(nPrime):
            perfect_square[j] += Y[i-nPrime][j]*M[row][i]
    # print("decomposition=")
    # print(perfect_square)
    # print("sqrt_x =",sqrt_x)

    for i in range(nPrime):
        sqrt_y = (sqrt_y * pow(prime[i],perfect_square[i]//2,n)) % n
#    print("sqrt_y =",sqrt_y)
    return (sqrt_x, sqrt_y)

#----------- main
random.seed(1234)

nPrime=30 # for n=2537123
nPrime=100 # for n=p4p5
prime=build_prime(nPrime)
print("The first",nPrime,"prime numbers are:")
print(prime)

XY=[]
Y=[]

n=2537123
p4p5=41758540882408627201
n=p4p5
# 479001599 is a non-trivial divisor of 4175854088240862720
# 87178291199 is a non-trivial divisor of 4175854088240862720
# found 5 times and 3 times in about 20 min.
# p4=479001599, p5=87178291199

print("n =",n)
nb_of_y=35
nb_of_y=120 # for n= p4p5

repeatFind_x_y(n,prime, XY, Y, nb_of_y)

# print("\nXY matrix=")
# for row in XY: print(row)
# print("\nY matrix=")
# for row in Y: print(row)

M=build_M(Y)

# print("\nM=")
# for row in M:
#     print(row)

print("-----")
Sol=GaussianElimnation(M,nPrime)
# print("Rows that are solution:")
# print(Sol)

# print("\nAfter Gaussian Elimination, M=")
# for row in M:
#     print(row)

for i in range(len(Sol)):
    (sqrt_x, sqrt_y)=find_perfect_square_root(M, prime, XY, Y, Sol, i, n)
    print(sqrt_x, sqrt_y, sqrt_x+sqrt_y)
    if sqrt_x != sqrt_y and sqrt_x+sqrt_y != n :
        g=gcd(sqrt_x+sqrt_y,n)
        print("  ",g,"is a non-trivial divisor of",n)
