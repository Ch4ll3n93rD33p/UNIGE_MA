def P(x,k,n):
    if k==n-1: return 1

def T(x,k,n):  # return a list of possible columns for x[k], including all conflicts
    column=[]
    if k<n:
        for col in range(n):
            for line in range(k):
                if col == x[line]: break # column conflict
                delta_x = abs(col-x[line])
                delta_y = abs(line-k)
                if delta_x == delta_y: break  # diagonal conflict
            else: column.append(col)
    return column # empty list if k>=n


def printSol(x,k,n):
    s=""
    for i in range(k+1):s+=str(x[i])+" "
    print(s)

# solved the placement from queen number k
def backtrack(x,k,n):
    if k == n: return (0,1)
    k_=k
    values=[ [] for  i in range(n+1)]

    values[k_]=T(x,k_,n)
    countNode=0  # to count the number of node generated
    while k_ > k-1:
        if len(values[k_])==0: 
            k_ -= 1
        else:
            x[k_]=values[k_].pop()
            countNode += 1
            if P(x,k_,n): return (countNode,1)  # solution found in countNode steps
            k_ += 1
            values[k_]=T(x,k_,n)
    return (countNode, 0) # no solution were found

#---------------------
n=8
x=[None for i in range(n)]

x[0]=1
x[1]=3

k=2
# then, place the other queens with BT
(s,success)=backtrack(x,k,n)
if success: print("Success in", s, "steps")
else: print("Failure of BT\n")
printSol(x, n-1, n)

