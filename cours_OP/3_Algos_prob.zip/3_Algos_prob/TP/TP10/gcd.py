def gcd(a,b):
    r0=a
    r1=b
    r2=r0%r1
    while r2 !=0 :
        r0=r1
        r1=r2
        r2=r0%r1
    return r1

a=3139
b=2537
print("The gcd of",a,"and",b, "is", gcd(a,b),"\n")


