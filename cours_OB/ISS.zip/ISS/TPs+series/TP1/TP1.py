# Lea Heiniger
# Information Systems Security
# TP 1

import functions as func


#encryption

key= "You can't see me"
binKey= func.charToByte(key)

msg ="Can you smell what the Rock is cooking?"
binMsg = func.charToByte(msg)
padded = func.pad(binMsg)

cipheredMsg=func.encryptionAES(padded, binKey)
print(cipheredMsg)

#the mix column step is not working

#decryption
#we need to convert the cipherText from a string of hexa decimal to a string of bits
#binMsg = func.decryptionAES(cipheredMsg, binKey)
