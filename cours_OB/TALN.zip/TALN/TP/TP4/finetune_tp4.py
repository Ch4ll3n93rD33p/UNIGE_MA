# Lea Heiniger
# 11.01.2024
# TALN - TP4

import functions as func
import sys
from itertools import chain

all_languages = ['Chinese', 'Croatian', 'Danish', 'English', 'Portuguese', 'Serbian', 'Slovak', 'Swedish']
train_filenames = ['UNER_Chinese-GSDSIMP/zh_gsdsimp-ud-train.iob2', 'UNER_Croatian-SET/hr_set-ud-train.iob2', 'UNER_Danish-DDT/da_ddt-ud-train.iob2', 'UNER_English-EWT/en_ewt-ud-train.iob2', 'UNER_Portuguese-Bosque/pt_bosque-ud-train.iob2', 'UNER_Serbian-SET/sr_set-ud-train.iob2', 'UNER_Slovak-SNK/sk_snk-ud-train.iob2', 'UNER_Swedish-Talbanken/sv_talbanken-ud-train.iob2']
test_filenames = ['UNER_Chinese-GSDSIMP/zh_gsdsimp-ud-test.iob2', 'UNER_Croatian-SET/hr_set-ud-test.iob2', 'UNER_Danish-DDT/da_ddt-ud-test.iob2', 'UNER_English-EWT/en_ewt-ud-test.iob2', 'UNER_Portuguese-Bosque/pt_bosque-ud-test.iob2', 'UNER_Serbian-SET/sr_set-ud-test.iob2', 'UNER_Slovak-SNK/sk_snk-ud-test.iob2', 'UNER_Swedish-Talbanken/sv_talbanken-ud-test.iob2']

chosen_model = "bert-base-multilingual-cased"

languages = sys.argv[1:]
indexes = [all_languages.index(l) for l in languages]

tokenizer = func.BertTokenizerFast.from_pretrained(chosen_model)

for i in range(len(languages)) :

    # Data tokenization
    X_train, Y_train = func.load_data(train_filenames[indexes[i]])
    X_test, Y_test = func.load_data(test_filenames[indexes[i]])
    
    len_sent = [len(s) for s in X_train+X_test]
    token_dict_train = func.tokenize(languages[i], X_train, max(len_sent), Y_train, tokenizer)
    token_dict_test = func.tokenize(languages[i], X_test, max(len_sent), Y_test, tokenizer)

    # Training
    dataset_train = func.CustomDataset(token_dict_train)
    dataset_train_ = func.DataLoader(dataset_train, batch_size = 16, shuffle = True)
    
    model = func.BertForTokenClassification.from_pretrained(chosen_model, num_labels=len(set(chain(*(Y_train+Y_test)))))
    dev = func.torch.device('cuda' if func.torch.cuda.is_available() else 'cpu')
    model.to(dev)
    
    optimizer_grouped_parameters = model.parameters()
    optimizer = func.AdamW(optimizer_grouped_parameters)
    model.train()
    
    func.train_(model, dataset_train_, dev, optimizer)
    
    # Testing
    dataset_test = func.CustomDataset(token_dict_test)
    dataset_test_ = func.DataLoader(dataset_test, batch_size = 16, shuffle = True)
    
    model.eval()
    dev = func.torch.device('cuda' if func.torch.cuda.is_available() else 'cpu')
    model.to(dev)

    Y_test, Y_pred = func.evaluate(languages[i], model, dataset_test_, dev)
    report = func.make_report(Y_test, Y_pred)
    func.write_report('compare_eval.txt', languages[i], report)