# TP3: Multilingual NER  

## How to run the script 

### Files  

The main scripts can be found in the _spacy\_tp3.py_  and _crf\_tp3.py_ files and uses the functions I've implemented in the _functions.py_ library.  
The _spacy\_reports.txt_ and _crf\_reports.txt_ files contain the reports. Unfortunately my spacy script has an error that I was unable to fix. Therefore I couldn't write the spacy reports.  

### Running  

Before running my scripts you have to make sure that you have (in the same directory than the scripts) the data sets downloaded and two empty files named _spacy\_reports.txt_ and _crf\_reports.txt_.  
  
Then you simply run  
`$ python3 spacy_tp3.py`  
or  
`$ python3 crf_tp3.py`  

## Running time  

For the crf script, I have a running time of 48.78257417678833 seconds.  
  
For the spacy script, since there is an error before the script reaches the end I couldn't compute the running time.  
  
## spaCy options

For the spacy script I used pre-trained models for each of the languages (using the spacy.load function to load them). The Serbian and the Slovak don't have specific pre-trained models, so I used a multilingual model instead.
