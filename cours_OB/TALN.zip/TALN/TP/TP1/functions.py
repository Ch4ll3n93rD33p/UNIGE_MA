# Lea Heiniger
# 26.10.2023
# TALN - TP1

import os
import string
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from collections import Counter

'''
This file is a library of functions used for the TP.
The main script can be found in the file "tp1.py".
'''

####### Raw text preprocessing #######

def text_preprocessing(filename : str) -> None :
    '''
    Function that creates a new file called raw_text.txt
    with the raw text preprocessed as required.

    WARNING: if a file called raw_text.txt already exists
    it will be overwritten !

    Parameters :
        filename -> the name of the raw text file
    '''
    with open(filename, 'r') as f :

        txt = ''
        for line in f :
            txt += line 
     
    txt = txt.lower() 
    no_punct = str.maketrans('', '', string.punctuation)
    txt = txt.translate(no_punct)
    txt = " ".join(txt.split())

    with open('raw_text.txt', 'w') as f :
        f.truncate(0)
        f.write(txt) 

def create_BandT(filename : str, nB : int = 200, nT : int = 100) -> None :
    '''
    Function that creates a new files B.txt and T.txt from the 
    preprocessed raw file

    WARNING: if a files called B.txt or T.txt already exists
    they will be overwritten !

    Parameters :
        filename -> the name of the preprocessed raw text file
        nB     -> the number of words that B should contain
        nT     -> the number of words that T should contain
    '''
    with open(filename, 'r') as f :
        rawtxt = ''
        for line in f :
            rawtxt += line
        
    frequencies = Counter(rawtxt.split()).most_common()

    wordsB = [w for w, _ in frequencies][:nB]
    wordsT = [w for w, _ in frequencies][nB:nB+nT]
    
    with open('B.txt', 'w') as b :
        b.truncate(0)
        for w in wordsB :
            b.write(w+os.linesep) 
    
    with open('T.txt', 'w') as t :
        t.truncate(0)
        for w in wordsT :
            t.write(w+os.linesep)      

####### 2D embeddings #######

def context_window(index : int, N : int, window_size : int) -> (int, int) :
    '''
    Function that computes the indexes of the context window

    Parameters :
        index      -> the index of the target word
        N         -> the maximum index
        window_size -> the size of the window
    
    Return :
        j   -> the index for the start of the window
        k   -> the index for the end of the window
    '''
    j = int(index-np.floor(window_size/2))
    if j<0 :
        j = 0
    k = int(index+np.ceil(window_size/2))
    if k>N :
        k = N

    return j, k

def co_occ_matrix(rawtxt : str, B : list, T : list, window_size : int = 5) -> np.ndarray :
    '''
    Function that computes the co-occurrency matrix 
    for the target words T and the context B.

    Parameters :
        rawtxt     -> the preprocessed raw text
        B         -> the list of context words
        T         -> the list of target words
        window_size -> the size of the context window
    
    Return :
        coM -> the co-occurrency matrix
    '''
    words_list = rawtxt.split(' ')
    N = len(words_list)
    coM = np.zeros((len(T), len(B)))
    
    for i in range(N) :
        w = words_list[i]
        if w in T :
            j, k = context_window(i, N-1, window_size)
            context = words_list[j:i]+words_list[i+1:k]
            for c in context :
                if c in B :
                    coM[T.index(w)][B.index(c)] += 1
                    
    return coM

def ppmi(M : np.ndarray) -> np.ndarray :
    '''
    Function that computes the PPMI matrix

    Parameters :
        M   -> the matrix on which we apply PPMI 
    
    Return :
        ppmiM -> the PPMI matrix
    '''
    expected_co = np.outer(np.sum(M, axis = 1), np.sum(M, axis = 0))/np.sum(M)
    ratio = M*np.sum(M)/(expected_co+10**(-8))
    with np.errstate(divide = 'ignore') :
        ppmiM = np.maximum(np.log2(ratio), 0)
    
    return ppmiM

def pca(dataset : np.ndarray) -> np.ndarray :
    '''
    Adapted from the notebook given with the tp
    Function that applies 2 components PCA on a dataset

    Parameters :
        dataset -> the matrix on which we apply PCA
    
    Return :
        pca_data -> the result of the computation
    '''
    p = PCA(n_components=2)
    p.fit(dataset)
    pca_data = p.transform(dataset)
    return pca_data

####### Most similar words #######

def cosine_sim(X : np.ndarray, Y : np.ndarray) -> np.float64 :
    '''
    Function that computes cosine similarity between vectors X and Y

    Parameters :
        X   -> the first vector
        Y   -> the second vector
    
    Return :
        sim -> the cosine similarity
    '''
    magnitude = np.linalg.norm(X)*np.linalg.norm(Y)
    if magnitude!=0 :
        sim = np.dot(X, Y)/magnitude
    else :
        sim = 0
    return sim

def most_sim_words(ppmiM : np.ndarray, T : list) -> list :
    '''
    Function that finds the most similar word for each target word.

    Parameters :
        ppmiM -> the PPMI matrix
        T    -> the target words
    
    Return :
        most_sim -> the list of target word - most similar word pairs
    '''
    nT = len(T)
    simM = np.zeros((nT, nT))
    for i in range(nT) :
        for j in range(nT) :
            simM[i, j] = cosine_sim(ppmiM[i], ppmiM[j])

    most_sim = []
    for i in range(nT):
        simM[i, i] = 0
        index = np.where(np.isclose(simM[i], np.max(simM[i])))[0][0]
        w = T[index]
        most_sim.append((T[i], w))
        
    return most_sim

####### Plot #######

def plot_words(X : np.ndarray, Y : np.ndarray, labels : list) -> None : 
    '''
    Adapted from the notebook given with the tp
    Function that plot the words in 2D space

    Parameters :
        X    -> First component of the PCA data
        Y    -> Second component of the PCA data
        labels -> List of words
    '''
    fig = plt.figure(figsize = (10, 10))
    ax = fig.add_subplot(111)
    ax.scatter(X, Y, s = 50, alpha = 0.6, edgecolors = 'w')

    for x, y, label in zip(X, Y, labels) :
        ax.text(x, y, label)

    plt.show()
