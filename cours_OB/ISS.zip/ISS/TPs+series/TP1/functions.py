# Lea Heiniger
# Information Systems Security
# TP 1

import numpy as np
from operator import xor
import Sboxes
import MultiplicationTables

def paddingSeq(bin, size=8) :
    '''
    Function that adds zeros in front of a string in order to have a string of length "size"

    Parameters :
     bin -> a binary string
     size -> leght that we want (default 8)

    Returning :
     bin -> the string padded
    '''
    while len(bin)<size :
        bin = "0"+bin
    return bin

def charToByte(msg) :
    '''
    Function that convert a string of characters to the ascii string corresponding

    Parameters :
     msg -> a string

    Returning :
     binMsg -> the string converted in ascii
    '''
    binMsg = ""

    for char in msg :
        binMsg = binMsg+paddingSeq(bin(ord(char))[2:])

    return(binMsg)

def slicing(msg, size=128) :
    '''
    Function that slice a string into blocks of size "size"

    Parameters :
     msg -> a string
     size -> leght of the blocks (default 128)

     Returning :
      slicedMsg -> a list of the blocks
     '''
    slicedMsg =[]
    i=0

    for i in range(len(msg)//size):
        slicedMsg.append(msg[i*size:(i+1)*size])

    return slicedMsg

def byteToChar(binMsg) :
    '''
    Function that convert a string in ascii to the corresponding string of characters

    Parameters :
     msg -> an ascii string

    Returning :
     binMsg -> the string converted in characters
    '''
    msg = ""
    binChars = slicing(binMsg, 8)

    for char in binChars :
        msg = msg + chr(int("0b"+char, 2))

    return msg

def pad(msg) :
    '''
    Function that pads the plainText

    Parameters :
     msg -> a binary string

    Returning :
     msg -> the string padded
    '''

    L = len(msg)//8
    r = L%16
    X = bin(16-r)[2:]

    X = paddingSeq(X)

    for i in range(16-r) : # we add X times X at the end of the string
        msg = msg + X

    return msg

def unpad(msg) :
    '''
    Function that unpads the plainText

    Parameters :
     msg -> a binary string

    Returning :
     msg -> the string unpadded
    '''

    L = len(msg)
    X = msg[L-8:]
    n = int("0b"+X,2)
    msg = msg[:L-8*n] # we remove the Xs added to the plain text

    return(msg)

def XOR(seq1, seq2) :
    '''
    Function that compute xor between two binary string

    Parameters :
     seq1 -> a binary string
     seq2 -> a binary string of same size as seq1

    Returning :
     res -> result of the xor opperation
    '''
    L = len(seq1)
    a = int("0b"+seq1,2)
    b = int("0b"+seq2,2)
    res = bin(xor(a,b))[2:]
    res = paddingSeq(res,L)
    return res

def rotation(seq) :
    '''
    Function rotate a binary string of one byte to the left

    Parameters :
     seq -> a binary string

    Returning :
     the string after the rotation
    '''
    return seq[8:]+seq[:8]

def SBox(seq,SB="norm") :
    '''
    Function that apply the SBox to a byte

    Parameters :
     seq -> a binary string of lenght 8
     SB -> "norm" for standard SBox and "inv" for invert SBox (default "norm")

    Returning :
     s -> the binary string corresponding to seq in the SBox
    '''
    r = int("0b"+seq[:4], 2)
    c = int("0b"+seq[4:], 2)
    if SB=="norm" :
        s = Sboxes.Sbox[r][c]
    elif SB=="inv" :
        s = Sboxes.Sbox_inv[r][c]

    return s

def keyExpention(key) :
    '''
    Function that computes the sub keys

    Parameters :
     key -> a binary string of lenght 128, 192 or 256

    Returning :
     W -> a list of the sub keys (each sliced in 4)
    '''
    dictR = {"128" : 11, "192" : 13, "256" : 15}
    rc = ["00000001", "00000010", "00000100", "00001000", "00010000", "00100000", "01000000", "10000000", "00011011", "00110110", "00000000", "00000000", "00000000"]

    keySize = len(key)
    N = keySize//32
    K = slicing(key, 32)
    R = dictR[str(keySize)] # number of sub keys needed

    W = []
    for i in range(4*R) :

        if i<N : #we return the original key for the round 0
            W.append(K[i])

        # We compute the sub-keys for the round 1 to R-1
        elif i>=N and i%N==0 :
            bytes = slicing(rotation(W[i-1]),8)
            newSeq = ""

            for b in bytes :
                s = SBox(b)
                newSeq += paddingSeq(bin(s)[2:])

            rcon = rc[(i//N)-1] + "000000000000000000000000"
            W.append(XOR(XOR(W[i-N], newSeq), rcon))

        elif i>=N and N>6 and i%N==4 :
            bytes = slicing(W[i-1],8)
            newSeq = ""
            for b in bytes :
                s = SBox(b)
                newSeq += paddingSeq(bin(s)[2:])

            W.append(XOR(W[i-N], newSeq))

        else :
            W.append(XOR(W[i-N], W[i-1]))

    return W

def asMatrix(block) :
    '''
    Function that transform a string into a 4 by 4 matrix

    Parameters :
     block -> a binary string of lenght 128

    Returning :
     M -> a matrix 4x4 (each element is a byte)
    '''

    M = [[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]]

    for i in range(4) :
        for j in range(4) : # we order the bytes by column and not by row
            M[i][j] = block[i*8+j*32:i*8+j*32+8]

    return M

def asString(M) :
    '''
    Function that transform a 4 by 4 matrix into a string

    Parameters :
     M -> a matrix 4x4 (each element is a byte)

    Returning :
     block -> a binary string of lenght 128

    '''
    block = ""

    for j in range(4) :
        for i in range(4) : # the elements were organised by column
            block = block+M[i][j]

    return block

def byteSub(B,SB="norm") :
    '''
    Function that perform byteSub step (applying sBox to each element of B)

    Parameters :
     B -> a matrix 4x4 (each element is a byte)
     SB -> "norm" for standard SBox and "inv" for invert SBox (default "norm")

    Returning :
     B -> the matrix after apllying the SBox to each element

    '''

    for i in range(4) :
        for j in range(4) :
            B[i][j] = paddingSeq(bin(SBox(B[i][j],SB))[2:])

    return B

def shiftRow(B,shift="l") :
    '''
    Function that perform shiftRow step (shifting the lements of B row by row)

    Parameters :
     B -> a matrix 4x4 (each element is a byte)
     shift -> "l" to shift to the left and "r" to shift to the right (default "l")

    Returning :
     B -> the matrix after shifting the rows

    '''
    for i in range(4) :
        #the first row is not shifted, the second is shifted 1 time, the third 2 times, ...
        if shift=="l" :
            B[i] =[B[i][(j+i)%4] for j in range(4)]
        elif shift=="r" :
            B[i] =[B[i][(j-i)%4] for j in range(4)]

    return B

def GFMult(m, col) :############## pas ok ?
    b=[]
    for i in range(4) :
        if m[i]==1 :
            b.append(col[i])
        else :
            seq = col[i]
            r = int("0b"+seq[:4], 2)
            c = int("0b"+seq[4:], 2)
            if m[i]==2 :
                mult=MultiplicationTables.M2[r][c]
            elif m[i]==3:
                mult=MultiplicationTables.M3[r][c]
            elif m[i]==9:
                mult=MultiplicationTables.M9[r][c]
            elif m[i]==11:
                mult=MultiplicationTables.M11[r][c]
            elif m[i]==13:
                mult=MultiplicationTables.M13[r][c]
            elif m[i]==14:
                mult=MultiplicationTables.M14[r][c]

            b.append(paddingSeq(bin(mult)[2:]))

    return b

def mixColumn(B,mult="norm") : ############## pas ok
    for j in range(4) :
        col = []
        for i in range(4) :
            col.append(B[i][j])

        if mult=="norm":
            m = [2,3,1,1]
        elif mult=="inv" :
            m=[14,11,13,9]
        newCol=[]
        for k in range(4) :
            b = GFMult(m, col)
            newCol.append(XOR(XOR(XOR(b[0],b[1]),b[2]),b[3]))
            m = [m[(i-1)%4] for i in range(4)]

        for i in range(4) :
            B[i][j] = newCol[i]

    return B

def encryptionAES(plainText, key) :
    dictRounds = {"128" : 10, "192" : 12, "256" : 14}
    blocks = slicing(plainText)
    W = keyExpention(key)
    rounds = dictRounds[str(len(key))]
    cipherText=""

    for b in blocks :
        init = XOR(b, W[0]+W[1]+W[2]+W[3]) #initial step
        B = asMatrix(init)

        for r in range(1,rounds+1) :
            print("r=",r)
            B = byteSub(B)
            print("sub")
            print(B)
            B = shiftRow(B,"r")
            print("shift")
            print(B)
            if r!=rounds :
                print("mix")
                B = mixColumn(B)
                print(B)

            b = asString(B)
            b = XOR(b,W[r*4]+W[r*4+1]+W[r*4+2]+W[r*4+3])
            B = asMatrix(b)
            print("add")
            print(B)
            print()

        cipherText = cipherText+hex(int("0b"+asString(B),2))[2:]

    return cipherText

def decryptionAES(cipherText, key) :
    dictRounds = {"128" : 10, "192" : 12, "256" : 14}
    blocks = slicing(cipherText)
    W = keyExpention(key)
    rounds = dictRounds[str(len(key))]
    plainText=""

    for b in blocks :
        init = XOR(b, W[0]+W[1]+W[2]+W[3]) #initial step
        B = asMatrix(init)

        for r in range(1,rounds+1) :
            B = byteSub(B,"inv")
            B = shiftRow(B)
            if r!=rounds :
                B = mixColumn(B,"inv")

            b = asString(B)
            b = XOR(b,W[r*4]+W[r*4+1]+W[r*4+2]+W[r*4+3])
            B = asMatrix(b)

        plainText = plainText+asString(B)
