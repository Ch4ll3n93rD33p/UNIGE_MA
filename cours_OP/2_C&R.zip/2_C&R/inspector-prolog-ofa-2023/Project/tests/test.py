
suspects = ["t"]
com="test(t)"
person = com.split("(")[1].split(")")[0]
print(suspects)
suspects.remove(person)
print(suspects)