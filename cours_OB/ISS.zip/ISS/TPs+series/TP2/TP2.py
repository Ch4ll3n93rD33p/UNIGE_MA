# Lea Heiniger
# Information Systems Security
# TP 2

import functions as func

P = "In a hole in the ground there lived a hobbit."
IV = "One ring to rule them all"
K = "Keep it secret !" #128, 192 or 256 bits
A = "Out of thefrying-pan into the fire"

print("We encrypte the plaintext (P) 'In a hole in the ground there lived a hobbit.' using Galois counter model encryption with the key (K) 'Keep it secret !', the initialisation value (IV) 'One ring to rule them all', and the additional authenticated data (A) 'Out of thefrying-pan into the fire'.")
print()
print("And we have")
C, T = func.encryptionGaloisCounterMode(P, IV, K, A)
print("- The ciphertext C : ", C)
print("- The authentication tag  T :", T)
print()
print("Then we decrypte the cipher text (using the same K, IV and A)")
print()
print("And we have")
P2 = func.decryptionGaloisCounterMode(C, T, IV, K, A)
print("The plaintext P' :", P2)
print()
if P2==P :
    print("P and P' are equals !")
else :
    print("there is a problem, P' is not equal to P")
