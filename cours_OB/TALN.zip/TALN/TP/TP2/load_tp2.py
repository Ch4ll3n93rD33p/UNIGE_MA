# Lea Heiniger
# 16.11.2023
# TALN - TP2

import functions as func
import sys
import time

'''
This file is the script that creates a sentence embedding using a pre-trained model. 
It uses functions implemented in the file "functions.py".
More information on my TP and the instructions on how to run the script can be 
found in the file "README.md".
'''

start = time.time()

arguments = sys.argv[1:]
filename = arguments[0]
model_name = arguments[1]

labels, sent = func.sent_preprocessing(filename)

# We load the pre-trained model
if '.bin' in model_name :
    word_vectors = func.KeyedVectors.load_word2vec_format(model_name, binary=True)
else :
    word_vectors = func.KeyedVectors.load_word2vec_format(model_name)

# We compute the sentence embedding
sent_vectors = func.get_sent_vectors(sent, word_vectors)
func.plot_sent_embedding(sent_vectors, labels, 'out1.1.png')

# We find the most similar sentence for each sentence (exept self)
most_sim_index = func.most_sim_sent(sent_vectors)
func.write_output('out1.2.txt', most_sim_index, labels)

end = time.time()
print('running time : '+str(end-start)+' s')