# Lea Heiniger
# Information Systems Security
# TP 3

import numpy as np
from operator import xor, and_
import SHAConstants
from copy import copy

def paddingSeq(bin, size=8) :
    '''
    Function that adds zeros in front of a string in order to have a string of length "size"

    Parameters :
     bin -> a binary string
     size -> leght that we want (default 8)

    Returning :
     bin -> the string padded
    '''
    while len(bin)<size :
        bin = "0"+bin
    return bin

def charToByte(msg) :
    '''
    Function that convert a string of characters to the ascii string corresponding

    Parameters :
     msg -> a string

    Returning :
     binMsg -> the string converted in ascii
    '''
    binMsg = ""

    for char in msg :
        binMsg = binMsg+paddingSeq(bin(ord(char))[2:])

    return(binMsg)

def XOR(seq1, seq2) :
    '''
    Function that compute xor between two binary string

    Parameters :
     seq1 -> a binary string
     seq2 -> a binary string of same size as seq1

    Returning :
     res -> result of the xor opperation
    '''
    L = len(seq1)
    a = int("0b"+seq1, 2)
    b = int("0b"+seq2, 2)
    res = bin(xor(a, b))[2:]
    res = paddingSeq(res, L)
    return res

def AND(seq1, seq2) :
    '''
    Function that compute and between two binary string

    Parameters :
     seq1 -> a binary string
     seq2 -> a binary string of same size as seq1

    Returning :
     res -> result of the bitwise and opperation
    '''
    L = len(seq1)
    a = int("0b"+seq1, 2)
    b = int("0b"+seq2, 2)
    res = bin(and_(a, b))[2:]
    res = paddingSeq(res, L)
    return res

def NOT(seq) :
    '''
    Function that compute the not oppreation on a binary string

    Parameters :
     seq -> a binary string

    Returning :
     res -> result of the not opperation
    '''
    res = ""

    for i in seq :
        res += str((int(i)+1)%2)

    return res

def pad(msg) :
    '''
    Function that pads the plainText

    Parameters :
     msg -> a binary string

    Returning :
     msg -> the string padded
    '''

    l = len(msg)
    msg += "1"
    K = 512-((l+1+64)%512)

    for i in range(K):
        msg += "0"

    L = bin(l)[2:]
    L = paddingSeq(L, size=64)

    msg += L

    return msg

def slicing(msg, size=512) :
    '''
    Function that slice a string into blocks of size "size"

    Parameters :
     msg -> a string
     size -> leght of the blocks (default 512)

     Returning :
      slicedMsg -> a list of the blocks
     '''
    slicedMsg =[]

    for i in range(len(msg)//size):
        slicedMsg.append(msg[i*size:(i+1)*size])

    return slicedMsg

def rightRotate(seq, x) :
    '''
    Function that rotate a binary string of x bit to the right

    Parameters :
     seq -> a binary string
     x -> the number of bit(s) to shift

    Returning :
     the string after the rotation
    '''
    l = len(seq)
    return seq[l-x:]+seq[:l-x]

def rightShift(seq, x) :
    '''
    Function that shifts a binary string of x bit to the right

    Parameters :
     seq -> a binary string
     x -> the number of bit(s) to shift

    Returning :
     the string shifted
    '''
    l = len(seq)
    seq = seq[:l-x]
    return paddingSeq(seq, size=l)

def add32(list) :
    '''
    Function compute addition mod 2^32

    Parameters :
     list -> a list of the terms we want to add (as binary strings)

    Returning :
     res -> The result of the addition mod 2^32
    '''
    res = 0
    for x in list :
        res += int('0b'+x, 2)

    res %= (2**32)
    res = bin(res)[2:]
    res = paddingSeq(res, 32)
    return res

def oneWayComp(block, H) :
    '''
    Function that computes the SHA-256 one-way compression

    Parameters :
     block -> a 512-bits binary string
     H -> a list of 8 32-bits binary strings (IV or the previous cipher)

    Returning :
     H -> the new cipher
    '''
    initH = copy(H)

    # We create the liste W of 64 32-bits words
    W = slicing(block, size=32)

    for i in range(16,64) :
        s0 = XOR(XOR(rightRotate(W[i-15], 7), rightRotate(W[i-15], 18)), rightShift(W[i-15], 3))
        s1 = XOR(XOR(rightRotate(W[i-2], 17), rightRotate(W[i-2], 19)), rightShift(W[i-2], 10))

        wi =add32([W[i-16], s0, W[i-7], s1])
        W.append(wi)

    # Compression Part
    K = list(SHAConstants.K)
    for i in range(len(K)) :
        K[i] = bin(K[i])[2:]
        K[i] = paddingSeq(K[i], 32)

    for i in range(64) :
        X1 = XOR(XOR(rightRotate(H[4], 6), rightRotate(H[4], 11)), rightRotate(H[4], 25))
        CH = XOR(AND(H[4], H[5]), AND(NOT(H[4]), H[6]))
        X2 = XOR(XOR(rightRotate(H[0], 2), rightRotate(H[0], 13)), rightRotate(H[0], 22))
        MAJ = XOR(XOR(AND(H[0], H[1]), AND(H[0], H[2])), AND(H[1], H[2]))
        temp1 = add32([H[7], X1, CH, K[i], W[i]])
        temp2 = add32([X2, MAJ])

        H[7], H[6], H[5] = H[6], H[5], H[4] # update h, g, f
        H[4] = add32([H[3], temp1]) # update e
        H[3], H[2], H[1] = H[2], H[1], H[0] # update d, c, b
        H[0] = add32([temp1, temp2]) # update a

    # Addition of inital H
    for i in range(8) :
        H[i] = add32([initH[i], H[i]])

    return H

def SHA256(msg) :
    '''
    Function that copute the digest of a string using SHA-256 one-way compression function

    Parameters :
     msg -> a string

    Returning :
     h -> The digest of msg
    '''
    binMsg = charToByte(msg)
    paddedMsg = pad(binMsg)
    blocks = slicing(paddedMsg)

    H = list(SHAConstants.IV)
    for i in range(len(H)) :
        H[i] = bin(H[i])[2:]
        H[i] = paddingSeq(H[i], 32)

    for b in blocks :
        H = oneWayComp(b, H)

    h = ""
    for i in range(8) :
        h += H[i]

    h = hex(int('0b'+h, 2))[2:] # convert h in hexadecimal

    return h
