# TP2: Sentence similarity with word2vec  

## How to run the script  

### Files  

The main scripts can be found in the _load\_tp2.py_  and _train\_tp2.py_ files and uses the functions I've implemented in the _functions.py_ library.  
The _out1.2.txt_ and _out2.2.txt_ files contain the asked results obtained with my scripts.  

### Running  

1. When running the first script (_load\_tp2.py_) you need to add the test file's name, containing a set of sentences, and the pre-trained model file's name.  
`$ python3 load_tp2.py <test filename> <model filename>`  
It will return the plot of the sentence embedding in the file _out.1.1.png_ as well as the most similar sentence ID for each sentence in the file _out1.2.txt_  

1. When running the second script (_train\_tp2.py_) you need to add the test file's name, containing a set of sentences.  
`$ python3 train_tp2.py <test filename>`  
It will return the plot of the sentence embedding in the file _out.2.1.png_ as well as the most similar sentence ID for each sentence in the file _out2.2.txt_. It will also store the trained model in the file _word2vec.model_

WARNING : If any files have the same name as the files we want to create, they will be rewritten !

## Running time  

For the first script, using the GoogleNews-vectors-negative300 pre-trained model, I have a running time of 38.82422208786011 secounds.  

For the secound script I have a running time of 53.42587637901306 secounds.

## gensim parameter settings  

### load\_tp2.py  

In the first script I use the non-default setting for the _binary_ parameter when using the _KeyedVectors.load\_word2vec\_format_ function :  
```word_vectors = func.KeyedVectors.load_word2vec_format(model_name, binary=True)```  
In the case where the given pre-trained model is in binary format.

### train\_tp2.py  

In the second script I use the parameter _sentences_  
```model = func.Word2Vec(sentences = corpus)```  
to train a word2vec model on my corpus.  

## Method  

In both scripts we use a word2vec model (either loaded or trained from a corpus) and based on this model we create a sentence embedding. For each sentence in the test file we create a vector by computing the mean of the vectors from each words (that we know from our word2vec sentence) in the sentence.  
In practice somme words in the test sentences could be missing from our word2vec model. In that case we just ignore them and take the next word in the sentence. This is not ideal but, since in both my trained model and the GoogleNews-vectors-negative300 model (that I used for the pre-trained model part)we only have a few missing words, the results are not too badly affected.  

## Training corpus  

I chose to use the text8 corpus. It is a corpus based on the English wikipedia and contains approximately 10^9 bytes of data. There are a few XHTML tags but most of the data is English plain text, so we have enough suitable data to train a word2vec model.  
