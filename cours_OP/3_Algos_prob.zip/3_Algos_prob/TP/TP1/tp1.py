# Lea Heiniger
# Probabilistic algorithms
# TP1

'''
EXERCISE 1 :

F(x) ax+b mod n a linear congrugent generator

with a = 65539, b=0 and n = 2^31
we whant to produce a sequence of xi to get a floting point number ri =xi/2^31 in [0, 1[

1) Program this random generator. Test that average of ri is 1/2

2) Generate triplets (ri, rii, riii) as a coordinate in a 3D cube [0,1]x[0,1]x[0,1] . Put a sphere of radius R at  (1/2, 1/2, 1/2). Compute the ratio M/N to see an aproximate of the volume of the sphere (4/3*pi*R^3)


3) We take another volume defined as c<= z-6y+9x <= c+Delta_c
with c = 2.5 and Delta_c = 0.1
'''

import numpy as np
import random
import matplotlib.pyplot as plt

#TODO scater plot in 3D
#TODO compare with python random

def F(x) : 
    return (65539*x)%(2**31)

def random_gen(i : int, seed : int = 1) -> float :
    x = seed
    for _ in range(i) :
        x = F(x)

    return x/(2**31)

def sphere(center : np.ndarray, radius : float) -> tuple[np.ndarray, np.ndarray, np.ndarray] :
    
    t = np.linspace(0, 2*np.pi)
    T, U = np.meshgrid(t, t)
    X = radius*np.cos(T)*np.sin(U)+center[0]
    Y = radius*np.sin(T)*np.sin(U)+center[1]
    Z = radius*np.cos(U)+center[2]

    return X, Y, Z

def plot_3d_surface(objects : list[np.ndarray], points : list[np.ndarray]) -> None :

    fig = plt.figure()
    ax = fig.add_subplot(111, projection = '3d')

    for o in objects :
        ax.plot_surface(o[0], o[1], o[2], alpha = 0.1)
    
    ax.scatter(points[:, 0], points[:, 1], points[:, 2])

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.set_aspect('equal')
    plt.show()

###### MAIN ######

# 1)
test = [random_gen(i) for i in range(100)]
average = np.mean(test)

print("1)")
print("Pour 100 nombres la moyenne est :", average)
print()

# 2)
points = []
python_points = []
i = 0
N = 1000

for j in range(N) :
    r1 = random_gen(i)
    r2 = random_gen(i+1)
    r3 = random_gen(i+2)
    points.append([r1, r2, r3])
    r4 = random.random()
    r5 = random.random()
    r6 = random.random()
    python_points.append([r4, r5, r6])
    i += 1

points = np.array(points)
python_points = np.array(python_points)

R = 0.4
M = 0
for p in points :
    if (((p[0]-0.5)**2+(p[1]-0.5)**2+(p[2]-0.5)**2) <= R**2) :
        M += 1

aprox_V = M/N
V = 4/3*np.pi*R**3

M_p = 0
for p in python_points :
    if (((p[0]-0.5)**2+(p[1]-0.5)**2+(p[2]-0.5)**2) <= R**2) :
        M_p += 1

aprox_V_p = M_p/N
s = sphere([0.5, 0.5, 0.5], R)

print("2)")
print("The volume of the sphere is ", V)
print("The aproximated volume is ", aprox_V)
print("The aproximation with python is ", aprox_V_p)
print()

plot_3d_surface([s], points)

# 3)

c = 2.5
Delta_c = 0.1
M = 0
for p in points :
    if c<=(p[2]-6*p[1]+9*p[0])<=c+Delta_c :
        M += 1

aprox_V = M/N

M_p = 0
for p in python_points :
    if c<=(p[2]-6*p[1]+9*p[0])<=c+Delta_c :
        M_p += 1

aprox_V_p = M_p/N

print("3)")
print("The aproximated volume is ", aprox_V)
print("The aproximation with python is ", aprox_V_p)
print()




