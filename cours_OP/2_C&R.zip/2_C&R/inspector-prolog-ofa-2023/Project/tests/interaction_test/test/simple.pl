person(joao).
