import sys
import numpy as np

""" Convert a ".lif" file into an input file """
x_min, x_max = 0, 0
y_min, y_max = 0, 0

with open("lifep/" + sys.argv[1], "r") as ifd:
    for line in ifd:
        line = line.strip()
        if len(line) < 2:
            continue
        if (line[0] == "#") & (line[1] == "P"):
            line = line.split()
            x = int(line[1])
            y = int(line[2])
            if x < x_min:
                x_min = x
            if x > x_max:
                x_max = x
            if y < y_min:
                y_min = y
            if y > y_max:
                y_max = y

x_len = x_max - x_min
y_len = y_max - y_min
dim_max = max(x_len, y_len) + 50

lattice = np.zeros((dim_max, dim_max), dtype=int)

with open("lifep/" + sys.argv[1], "r") as ifd:
    for line in ifd:
        line = line.strip()
        if line[0] == "#":
            if len(line) < 2:
                continue
            if line[1] != "P":
                continue
            else:
                line = line.split()
                x = int(line[1]) - x_min
                y = int(line[2]) - y_min
                current_y = 0
                continue
        
        line = line.replace(".", "0")
        line = line.replace("*", "1")
        line = np.array(list(line), dtype=int)
        lattice[y + current_y, x:(x+len(line))] = line
        current_y += 1

name = sys.argv[1].split(sep=".")
with open("exemples/" + name[0] + ".data", "w") as fd:
    nrow, _ = np.shape(lattice)
    for i in range(nrow):
        row = lattice[i,:]
        line = " ".join(list(row.astype(str)))
        fd.write(line + "\n")
