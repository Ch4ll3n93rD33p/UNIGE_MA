from random import randint

def partition(A,m,p):
   if m==p: return m
   pivot=A[m]
   i=m
   q=p+1
   while i<q:
      while 1:
         i+=1
         if i>=p or A[i]>=pivot: break
      while 1:
         q-=1
         if A[q]<= pivot: break
      if i<q:  (A[i],A[q])=(A[q],A[i])
   (A[m],A[q])=(A[q],A[m])
   return q

# --- example of how partition works
A=[6,1,7,-5,2,8,4,6]
print(A)
print("q=", partition(A,0,len(A)-1))
print(A)


def quickSort(A,p,q):
    if p>=q: return # end condition
    j=partition(A,p,q)
    quickSort(A,p,j-1)
    quickSort(A, j+1,q)


# examples of quicksort
A=[6,1,7,-5,2,8,4,6]
quickSort(A,0,len(A)-1)
print(A)
print("--------")

n=50
A=[randint(0,7) for i in range(n)]
print(A)
quickSort(A,0,len(A)-1)
print(A)

