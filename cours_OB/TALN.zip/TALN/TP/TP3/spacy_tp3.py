# Lea Heiniger
# 14.12.2023
# TALN - TP3

import spacy
import functions as func
import time

start = time.time()

### load pre-trained models ###
zh_model = spacy.load("zh_core_web_sm")
hr_model = spacy.load("hr_core_news_sm")
da_model = spacy.load("da_core_news_sm")
en_model = spacy.load("en_core_web_sm")
pt_model = spacy.load("pt_core_news_sm")
sr_model = spacy.load("xx_ent_wiki_sm")
sk_model = spacy.load("xx_ent_wiki_sm")
sv_model = spacy.load("sv_core_news_sm")

languages = ['Chinese', 'Croatian', 'Danish', 'English', 'Portugese', 'Serbian', 'Slovak', 'Swedish']
models = [zh_model, hr_model, da_model, en_model, pt_model, sr_model, sk_model, sv_model]
test_filenames = ['UNER_Chinese-GSDSIMP/zh_gsdsimp-ud-test.iob2', 'UNER_Croatian-SET/hr_set-ud-test.iob2', 'UNER_Danish-DDT/da_ddt-ud-test.iob2', 'UNER_English-EWT/en_ewt-ud-test.iob2', 'UNER_Portuguese-Bosque/pt_bosque-ud-test.iob2', 'UNER_Serbian-SET/sr_set-ud-test.iob2', 'UNER_Slovak-SNK/sk_snk-ud-test.iob2', 'UNER_Swedish-Talbanken/sv_talbanken-ud-test.iob2']

for i in range(8) :

    X_test, labels = func.load_data(test_filenames[i])
    X_test = func.concatenate_tokens(X_test)
    model = models[i]

    Y_pred = []
    Y_test = []
    for  j in range(len(X_test)) : 
        doc = model(X_test[j])
        p = func.format(doc)
        l = labels[j]

    if len(p) == len(l):
            Y_pred.extend(p)
            Y_test.extend(l)
            
    report = func.make_report(Y_test, Y_pred)
    func.write_report('spacy_reports.txt', languages[i], report)

end = time.time()
print('running time : '+str(end-start)+' s')