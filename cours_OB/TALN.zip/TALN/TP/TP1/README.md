Lea Heiniger  
26.10.2023  
  
# TALN - TP1 : Word vectors from scratch  
  
## The files  
  
The main script can be found in the _tp1.py_ file and uses the functions I've implemented in the _functions.py_ library.  
The _B.txt_ and _T.txt_ files contain the B and T obtained with my script from my corpus.  
  
## Corpus choice  
  
As a corpus I have chosen to use the text of Moby Dick by Herman Melville (which is part of the public domain). I made this choice because the text is freely available without copyright and is 213,638 words long, which is sufficient for this course. But having this book as my only source has the disadvantage of the language used being a bit dated and the book's theme having more of an impact on the results than if we took a corpus of different texts.  
  
## How to run the script  
  
There are two options for running my script :  
  
1. You can run it with a pre-processed raw text and existing B and T files using the following command  
`$ python3 tp1.py <raw text filename> <B filename> <T filename>`  
  
2. You can run it with just a raw text file using the option _-p_ so that it is pre-processed as required and to create the B and T files.  
`$ python3 tp1.py -p <raw text filename>`  

By default, B contains 200 words and T 100, but you can specify other sizes as follows  
`$ python3 tp1.py -p <raw text filename> <B size> <T size>`  
  
In both cases the default size of the context window is 5, but this can be changed with the option _-ws_  
`$ python3 tp1.py <raw text filename> <B filename> <T filename> -ws <window size>`  
`$ python3 tp1.py -p <raw text filename> <B size> <T size> -ws <window size>`  
  
### Exemples  
  
`$ python3 tp1.py raw_text.txt B.txt T.txt -ws 7`  
The command will launch the script on pre-existing files with a context window size of 7 (3 words before and 3 words after the target word).  
  
`$ python3 tp1.py -p moby_dick.txt 100 50`  
We will create a new file called raw_text.txt which will contain the pre-process text as well as a B.txt file which will contain 100 words and a T.txt file which will contain 50 words, before executing the rest of the script.  
WARNING : If any files have the same name as the files we want to create, they will be rewritten !  
  