import random

def MillerRabin(n):
    a=random.randint(2,n-2)
    return Btest(a,n)

def Btest(a,n):
    s=0
    t=n-1
    while t%2 == 0:
        s+=1
        t//=2
    x=pow(a,t,n)
    if x==1 or x==n-1 : return True

    for i in range(s):
        x=(x*x)%n
        if x==n-1: return True
    return False

p1=31
p2=999331
p3=39916801
p4=479001599
p5= 87178291199
p6=67280421310721
p7=999779999159200499899

M_127=170141183460469231731687303715884105727  # 2**127 - 1
p8=20988936657440586486151264256610222593863921

q_false=651693055693681

n=q_false
#n=p8
if MillerRabin(n): print(n,"is likely prime")
else: print(n,"is composite")

n=289
count=0
for a in range(2,n-1):
    if Btest(a,n):
        print(a,"is in B(n)")
        count+=1

print("B(n) contains", count,"elements")
print("Probability of error =",count/n)

