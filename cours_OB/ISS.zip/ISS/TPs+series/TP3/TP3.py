# Lea Heiniger
# Information Systems Security
# TP 3

import functions as func

print("We test the function on the three exemples given in the file SHAConstants.py and see if we have the right digest.")
print()
print("First exemple : ",func.SHAConstants.ex1,"(empy string)")
digest1 = func.SHA256(func.SHAConstants.ex1)
print("We obtain the following digest : ",digest1)
print("And we compare it to the expected result : ")
d = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"

if digest1==d :
    print("The two digest are equals")
else :
    print("The two digest are not equals")

print()


print("Second exemple : ",func.SHAConstants.ex2)
digest2 = func.SHA256(func.SHAConstants.ex2)
print("We obtain the following digest : ",digest2)
print("And we compare it to the expected result : ")
d = "70eeb26f0052ebe0041e58d221e954c575f32a979cefdae7b761969e33b7934f"

if digest2==d :
    print("The two digest are equals")
else :
    print("The two digest are not equals")

print()

print("Third exemple : ",func.SHAConstants.ex3)
digest3 = func.SHA256(func.SHAConstants.ex3)
print("We obtain the following digest : ",digest3)
print("And we compare it to the expected result : ")
d = "31bba5997ae84193407798293636745b88d0126146fd105aa96e599c5f197714"

if digest3==d :
    print("The two digest are equals")
else :
    print("The two digest are not equals")
