# TP4: Transfer learning for Multilingual NER  

The script is unfortunately not fully functional. When I apply the model to my data (at lines 121 and 143 of the _functions.py_ file) I get an error "IndexError: Target -1 is out of bounds" and despite all my attempts I couldn't figure out how to solve it.  
I've done my best to implement the rest anyway to show my reasoning and in the hope that it will be functional once the problem has been solved.  

## How to run the script  

### Files  

The main script can be found in the _finetune\_tp4.py_ file and uses the functions I've implemented in the _functions.py_ library.  
The _compare\_eval.txt_ file should contain the reports.  

### Running  

Before running my scripts you have to make sure that you have (in the same directory than the scripts) the data sets downloaded and an empty file named _compare\_eval.txt_.  
  
Then you simply run  
`$ python3 finetune_tp4.py <Language1> <Language2> <Language3> ...`  

Where the _LanguageX_ parameters are the names of the languages (starting with a capital letter) for which we want to run the script. These parameters are optional (you can put a single language or several languages).

## Pre-trained models  

I used the _bert-base-multilingual-cased_ pre-trained model. Since it is a multilingual model we can use it for all of the languages from our list.  
