ciphertext = """wyimhwisigjrqevdiiavhimevrwzighfkaphjtrrglgegepriqwvrdrreioiwyicrpgenbvdsswujycfhjwfxowvaqfymshvklevhimevsftuodimtbvgenvvvzeudcriqwvrdrffrsrovwwlwyxhhizvswuxemhpvxrrluveohrwegleriqhkieqhzkhwbjmxirixhhqzrthquseqwvvtdleqeqwjcswhdvtkhditurzhgdpvwckufrifovxhhpzwslrewoiefynwbyynwhiwapxjerdqzravfzinfhwmcwlfrrvhkxiqjnlifktsnwdzrspdecslpzpaulkmevwfxhhdcmeqizpmiurrckljichqkvaoscsthovqeqwjvauhklephkvolgfvgdqzwmvdehtkhjtafhgmrdwvwwkltltubkseascsiwwyimhwisigvgswhujxhhuxemhsceyfrdfiqhjedyhexuuhseshgfreascsrdwzsndqumthpxetkhimnjzzxhsorxfrudirdquvskrfxeugprapltwtkhditurzhgdpvwauhwemrxjjouwyiiuqfrllqverjddipodpahhuvsnhfrrrfrdtlhwvegdpvaiwkrjrdfkmoqrwxhhlkimvdmeiodspelqklejddirwkvveduvsvhurhochekaphjmnwkvweulvwtkljmnfolhevizzepdzrgdpvwmhwisigpvxrrluxwruiitxuesfvddysvxgirphkvolgditurzhfxvzsndquqewufmdguvedwzfwplqfjfjddisirixhhuemnwhehogvwemlopqewufmdsuzqeslefaoorrdphkvolggviphwidhurxirqwsrfhrjiuvkteuvfrrdgminwxiigdpvaiwknmrhovwsdqusnoleimxokmpodpirphkvolggviphyynwhiwtkhditurzhpuldirwuzpojbditurzhpuldimhwisigsimmhwnsefkfisdquqewufmdsuzqewkiiefrivuswzsndquvmhwisigrkleuprwwhocesydimoxvfxhhugsrwvrrduhdekhv"""

# The maximum key size : you know the key's length is inferior or equal to 10
maximum_key_size = 10

# Mean frequences for each character in the english language
# (as percentages : for example, 0.0808 = 8.08%)
english_freq = [0.0808, 0.0167, 0.0318, 0.0399, 0.1256, 0.0217, 0.0180, \
                  0.0527, 0.0724, 0.0014, 0.0063, 0.0404, 0.0260, 0.0738, \
                  0.0747, 0.0191, 0.0009, 0.0642, 0.0659, 0.0915, 0.0279, \
                  0.0100, 0.0189, 0.0021, 0.0165, 0.0007]

